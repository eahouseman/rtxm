setMethod("adaptivate",
          "rtxmBasicProfileREffModel",
   function(theObject){
      ret <- callNextMethod(theObject)
      if(ret < -1) return(ret)

      catch <- try({
        theObject$initPackage[[1]]$alpha <- rep(0, theObject$index1$n)
        theObject$initPackage[[1]]$tauA <- 0.1 * theObject$initPackage[[1]]$tauZ 


        # Changed 1/23/2018; delete random number seed specs from variable list
        #   (var list originally constructed from init list, which may have RNG specs)
        sampVars <- names(theObject$initPackage[[1]])
        theObject$sampleAllVariables <- setdiff(sampVars, c(".RNG.name",".RNG.seed"))


        theObject$sampleStandard <- theObject$sampleAllVariables
      }) 
     if(inherits(catch,"try-error")) return(-2)

     return(-1)      
   }

)

setMethod("postprocess",
          "rtxmBasicProfileREffModel",
   function(theObject){
      s <- theObject$status

      rtxmSamplerPostProcessBasic(theObject, s)

      sampVarNames <- colnames(theObject$sampleHistory[[s]][[1]])

      theObject$sampleVarIndex[[s]]$precisionAlpha <- grep("tauA", sampVarNames)
      theObject$sampleVarIndex[[s]]$profileIntercepts <- grep("^alpha", sampVarNames)

      names(theObject$sampleVarIndex[[s]]$profileIntercepts) <- names(theObject$index1$forward)

      theObject$status+1
   }
)

setMethod("getCoefficients",
          "rtxmBasicProfileREffModel",
   function(theObject, which=NULL, vindex=NULL, whichSet="all"){
     if(whichSet=="task"|whichSet=="fixed"){
       getVariableBlock(theObject,"coefficients",
           which=which,vindex=vindex)
     }
     else if(whichSet=="profileIntercepts"){
        getVariableBlock(theObject,"profileIntercepts",
           which=which,vindex=vindex)
     }
     else if(whichSet=="all"){
       cbind(
         getVariableBlock(theObject,"coefficients",
             which=which,vindex=vindex),
         getVariableBlock(theObject,"profileIntercepts",
             which=which,vindex=vindex)
       )
     }
   }
)

setMethod("summary",
          "rtxmBasicProfileREffModel",
   function(object, which=NULL){
      ret <- callNextMethod(object, which=which)

      if(is.null(which)) which <- object$status-1
      v <- object$sampleVarIndex[[which]]

      ret[["alpha standard deviation"]] <- rtxmStandardPosterior(
            getVarianceComponents(object, "precisionAlpha", which=which, vindex=v),
            stats=c(0.025,0.5,0.975))
      ret
   }
)

setMethod("getPredictions",
          "rtxmBasicProfileREffModel",
   function(theObject, whichComponent, which=NULL, vindex=NULL, level=1){
      if(is.null(which)) which <- theObject$status-1

      # Check to see if they've been calculated already
      if(!is.null(theObject$predictions)){ 
          if(theObject$predictions$which == which) 
             return(theObject$predictions$mu)
      }

      # If not, calculate and save them
      v <- theObject$sampleVarIndex[[which]]

      if(level==0){
        dsgn <- cbind(1,theObject$dataPackage$task)
        beta <- rbind(
          t(getIntercept(theObject, which=which, vindex=v)),
          t(getCoefficients(theObject, which=which, vindex=v, whichSet="task"))
        )
        sampMu <- dsgn %*% beta 
      }
      else {
        beta <- t(getCoefficients(theObject, which=which, vindex=v, whichSet="task"))
        sampMu <- theObject$dataPackage$task %*% beta 
      }

      if(level>=1){
        alpha <- getCoefficients(theObject, which=which, vindex=v, whichSet="profileIntercepts")
        for(i in 1:theObject$index1$n){
          zeta <- getVariableBlock(theObject,"zeta",which=which,vindex=vindex,vsubRow=i)

          ii <- theObject$index1$forward[[i]]
          sampMu[ii,] <- sampMu[ii,]+ theObject$spline[ii,] %*% t(zeta) 
          sampMu[ii,] <- sweep(sampMu[ii,],2,alpha[,i],"+")
        }
      }
      theObject$predictions <- list(which=which, mu=sampMu)
      sampMu     
   }
)

rtxmPlotBasicREffTraceDist <- function(x, what, which, panels=3, ...){
    xfuntag <- gsub("^[.][[:alpha:]]*[.]","", what[1])
    pfuntag <- gsub("[.][[:alpha:]]*$","", what[1])
    xfun <- list(
      `tasks`=expression( getTaskMeans(x, which=which) ), 
      `sdEpsilon`=expression( getVarianceComponents(x, "epsilon", which=which) ), 
      `sdZeta`=expression( getVarianceComponents(x, "zeta", which=which) ), 
      `sdAlpha`=expression( getVarianceComponents(x, "precisionAlpha", which=which) ), 
      `coefs`=expression({
           o <- cbind(getIntercept(x,which=which),getCoefficients(x, which=which))
           colnames(o)[1] <- "(Intercept)"
           o
      }), 
      `fixed`=expression({
           o <- cbind(getIntercept(x,which=which),getCoefficients(x, which=which, whichSet="fixed"))
           colnames(o)[1] <- "(Intercept)"
           o
      }),
      `random`=expression({
           o <- getCoefficients(x, which=which, whichSet="profileIntercepts")
           o
      }))[[xfuntag]]

    pfun <- list(
      `.trace`=expression( rtxmTracePlot(xm, panels, ...) ),
      `.density`=expression( rtxmDensityPlot(xm, panels, ...) )
    )[[pfuntag]]
    xm <- eval(xfun)
    eval(pfun)
}

setMethod("plot",
          "rtxmBasicProfileREffModel",
   function(x, what, which=NULL, panels=3, ...){

    if(what==".obsvpred"){
        rtxmPlotBasicObsVPred(x, which, ...)
    }
    else {
       rtxmPlotBasicREffTraceDist(x, what, which, panels=panels, ...)
    }
  }
)

