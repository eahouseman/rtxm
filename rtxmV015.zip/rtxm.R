# Load required libraries & functions
library(splines)  # Spline library
library(nlme)
library(rjags)

source("rtxmModelJAGSDefinitions.R")
source("rtxmModelDefinitions.R")
source("rtxmBase.R")