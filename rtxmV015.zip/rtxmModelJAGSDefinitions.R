.rtxmBASICMODELDEFINITIONS <- c(
  `BASIC`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          for(j in 1:D){
            zeta[it,j] ~ dnorm(0, tauZ)
          }
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muTask[h] <-  beta0 + inprod(task[h,1:P],beta[1:P])
          mu[h] <-  muTimedep[h] + muTask[h]
          Y[h] ~ dnorm(mu[h], tauE[idTask[h]])
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  ",
  `BASICLOD`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          for(j in 1:D){
            zeta[it,j] ~ dnorm(0, tauZ)
          }
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muTask[h] <-  beta0 + inprod(task[h,1:P],beta[1:P])
          mu[h] <-  muTimedep[h] + muTask[h]
        }

        for(g1 in 1:NDetect){
          yDetect[g1] ~ dnorm(mu[detectIndex[g1]], tauE[idTask[detectIndex[g1]]])
        }

        for(g0 in 1:NnonDetect){
          yNonDetect[g0] ~ dnorm(mu[nonDetectIndex[g0]], tauE[idTask[nonDetectIndex[g0]]])
          isDetectND[g0] ~ dinterval(yNonDetect[g0] , DETECTLIMIT)
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  ",
  `BASICWCOVARIATES`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          for(j in 1:D){
            zeta[it,j] ~ dnorm(0, tauZ)
          }
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muTask[h] <-  beta0 + inprod(task[h,1:P],beta[1:P])
          muExtra[h] <- inprod(covariates[h,1:nCovariates], xi[1:nCovariates])
          mu[h] <-  muTimedep[h] + muTask[h] + muExtra[h]
          Y[h] ~ dnorm(mu[h], tauE[idTask[h]])
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(r in 1:nCovariates){
          xi[r] ~ dnorm(0,XIPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  ",
  `BASICLODWCOVARIATES`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          for(j in 1:D){
            zeta[it,j] ~ dnorm(0, tauZ)
          }
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muExtra[h] <- inprod(covariates[h,1:nCovariates], xi[1:nCovariates])
          muTask[h] <-  beta0 + inprod(task[h,1:P],beta[1:P])
          mu[h] <-  muTimedep[h] + muTask[h] + muExtra[h]
        }

        for(g1 in 1:NDetect){
          yDetect[g1] ~ dnorm(mu[detectIndex[g1]], tauE[idTask[detectIndex[g1]]])
        }

        for(g0 in 1:NnonDetect){
          yNonDetect[g0] ~ dnorm(mu[nonDetectIndex[g0]], tauE[idTask[nonDetectIndex[g0]]])
          isDetectND[g0] ~ dinterval(yNonDetect[g0] , DETECTLIMIT)
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(r in 1:nCovariates){
          xi[r] ~ dnorm(0,XIPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  ",
  `BASIC_PROFILEREFF`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)
        tauA ~ dnorm(0,1.0E-6)T(0,1.0E10)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          for(j in 1:D){
            zeta[it,j] ~ dnorm(0, tauZ)
          }
          alpha[it] ~ dnorm(beta0, tauA)
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muTask[h] <-  alpha[idProfile[h]] + inprod(task[h,1:P],beta[1:P])
          mu[h] <-  muTimedep[h] + muTask[h]
          Y[h] ~ dnorm(mu[h], tauE[idTask[h]])
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  ",
  `PROFILEREFF_LOD`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)
        tauA ~ dnorm(0,1.0E-6)T(0,1.0E10)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          for(j in 1:D){
            zeta[it,j] ~ dnorm(0, tauZ)
          }
          alpha[it] ~ dnorm(beta0, tauA)
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muTask[h] <-  alpha[idProfile[h]] + inprod(task[h,1:P],beta[1:P])
          mu[h] <-  muTimedep[h] + muTask[h]
        }

        for(g1 in 1:NDetect){
          yDetect[g1] ~ dnorm(mu[detectIndex[g1]], tauE[idTask[detectIndex[g1]]])
        }

        for(g0 in 1:NnonDetect){
          yNonDetect[g0] ~ dnorm(mu[nonDetectIndex[g0]], tauE[idTask[nonDetectIndex[g0]]])
          isDetectND[g0] ~ dinterval(yNonDetect[g0] , DETECTLIMIT)
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  ",
  `PROFILEREFF_WCOVARIATES`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)
        tauA ~ dnorm(0,1.0E-6)T(0,1.0E10)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          for(j in 1:D){
            zeta[it,j] ~ dnorm(0, tauZ)
          }
          alpha[it] ~ dnorm(beta0, tauA)
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muTask[h] <-  alpha[idProfile[h]] + inprod(task[h,1:P],beta[1:P])
          muExtra[h] <- inprod(covariates[h,1:nCovariates], xi[1:nCovariates])
          mu[h] <-  muTimedep[h] + muTask[h] + muExtra[h]
          Y[h] ~ dnorm(mu[h], tauE[idTask[h]])
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(r in 1:nCovariates){
          xi[r] ~ dnorm(0,XIPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  ",
  `PROFILEREFF_LODWCOVARIATES`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)
        tauA ~ dnorm(0,1.0E-6)T(0,1.0E10)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          for(j in 1:D){
            zeta[it,j] ~ dnorm(0, tauZ)
          }
          alpha[it] ~ dnorm(beta0, tauA)
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muExtra[h] <- inprod(covariates[h,1:nCovariates], xi[1:nCovariates])
          muTask[h] <-  alpha[idProfile[h]] + inprod(task[h,1:P],beta[1:P])
          mu[h] <-  muTimedep[h] + muTask[h] + muExtra[h]
        }

        for(g1 in 1:NDetect){
          yDetect[g1] ~ dnorm(mu[detectIndex[g1]], tauE[idTask[detectIndex[g1]]])
        }

        for(g0 in 1:NnonDetect){
          yNonDetect[g0] ~ dnorm(mu[nonDetectIndex[g0]], tauE[idTask[nonDetectIndex[g0]]])
          isDetectND[g0] ~ dinterval(yNonDetect[g0] , DETECTLIMIT)
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(r in 1:nCovariates){
          xi[r] ~ dnorm(0,XIPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  ",
  `BASICLODS`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          for(j in 1:D){
            zeta[it,j] ~ dnorm(0, tauZ)
          }
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muTask[h] <-  beta0 + inprod(task[h,1:P],beta[1:P])
          mu[h] <-  muTimedep[h] + muTask[h]
        }

        for(g1 in 1:NDetect){
          yDetect[g1] ~ dnorm(mu[detectIndex[g1]], tauE[idTask[detectIndex[g1]]])
        }

        for(g0 in 1:NnonDetect){
          yNonDetect[g0] ~ dnorm(mu[nonDetectIndex[g0]], tauE[idTask[nonDetectIndex[g0]]])
          isDetectND[g0] ~ dinterval(yNonDetect[g0] , detectLimit[g0])
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  ",
  `BASICLODSWCOVARIATES`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          for(j in 1:D){
            zeta[it,j] ~ dnorm(0, tauZ)
          }
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muExtra[h] <- inprod(covariates[h,1:nCovariates], xi[1:nCovariates])
          muTask[h] <-  beta0 + inprod(task[h,1:P],beta[1:P])
          mu[h] <-  muTimedep[h] + muTask[h] + muExtra[h]
        }

        for(g1 in 1:NDetect){
          yDetect[g1] ~ dnorm(mu[detectIndex[g1]], tauE[idTask[detectIndex[g1]]])
        }

        for(g0 in 1:NnonDetect){
          yNonDetect[g0] ~ dnorm(mu[nonDetectIndex[g0]], tauE[idTask[nonDetectIndex[g0]]])
          isDetectND[g0] ~ dinterval(yNonDetect[g0] , detectLimit[g0])
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(r in 1:nCovariates){
          xi[r] ~ dnorm(0,XIPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  ",
  `PROFILEREFF_LODS`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)
        tauA ~ dnorm(0,1.0E-6)T(0,1.0E10)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          for(j in 1:D){
            zeta[it,j] ~ dnorm(0, tauZ)
          }
          alpha[it] ~ dnorm(beta0, tauA)
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muTask[h] <-  alpha[idProfile[h]] + inprod(task[h,1:P],beta[1:P])
          mu[h] <-  muTimedep[h] + muTask[h]
        }

        for(g1 in 1:NDetect){
          yDetect[g1] ~ dnorm(mu[detectIndex[g1]], tauE[idTask[detectIndex[g1]]])
        }

        for(g0 in 1:NnonDetect){
          yNonDetect[g0] ~ dnorm(mu[nonDetectIndex[g0]], tauE[idTask[nonDetectIndex[g0]]])
          isDetectND[g0] ~ dinterval(yNonDetect[g0] , detectLimit[g0])
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  ",
  `PROFILEREFF_LODSWCOVARIATES`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)
        tauA ~ dnorm(0,1.0E-6)T(0,1.0E10)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          for(j in 1:D){
            zeta[it,j] ~ dnorm(0, tauZ)
          }
          alpha[it] ~ dnorm(beta0, tauA)
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muExtra[h] <- inprod(covariates[h,1:nCovariates], xi[1:nCovariates])
          muTask[h] <-  alpha[idProfile[h]] + inprod(task[h,1:P],beta[1:P])
          mu[h] <-  muTimedep[h] + muTask[h] + muExtra[h]
        }

        for(g1 in 1:NDetect){
          yDetect[g1] ~ dnorm(mu[detectIndex[g1]], tauE[idTask[detectIndex[g1]]])
        }

        for(g0 in 1:NnonDetect){
          yNonDetect[g0] ~ dnorm(mu[nonDetectIndex[g0]], tauE[idTask[nonDetectIndex[g0]]])
          isDetectND[g0] ~ dinterval(yNonDetect[g0] , detectLimit[g0])
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(r in 1:nCovariates){
          xi[r] ~ dnorm(0,XIPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  "
)