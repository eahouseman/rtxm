setMethod("initialize",
          "rtxmBasicLODCovariatesModel",
     function(.Object, yResponse, xTask, data, timeSpline, LOD, zCovariates=NULL, gGroups=NULL,  
        transform=function(u)as.vector(u), initialImpute=NULL, localfile=tempfile(),
          rng.seed=NULL, rng.name="base::Mersenne-Twister" # added 1/19/2018
      ){
        .Object <- callNextMethod(.Object, yResponse, xTask, data=data, 
           timeSpline=timeSpline, zCovariates=zCovariates,
           gGroups=gGroups, transform=transform, localfile=localfile,
           rng.seed=rng.seed, rng.name=rng.name) # added 1/19/2018

        rtxmInitBasicLODModel(.Object, LOD, initialImpute)
     }
)

setMethod("show", signature="rtxmBasicLODCovariatesModel",
  definition=function(object){
     rtxmSamplerPrintBasic(object, function(o){
         cat("Limit-of-detection:",o@LOD,"\n")
         cat("Percent non-detect:",round(100*mean(o$Y<=o$transform(o@LOD)),1),"\n\n")
     })
  }
)

setMethod("adaptivate",
          "rtxmBasicLODCovariatesModel",
   function(theObject){
     catch <- try({
       theObject$dataPackage <- rtxmDataPackageBasic(theObject)

       theObject$dataPackage$XIPRECISION <- as.vector(theObject@hyperparameters["XIPRECISION"])
       theObject$dataPackage$covariates <- theObject$Z
       theObject$dataPackage$nCovariates <- theObject@nCovariates

       transLOD <- theObject$transform(theObject@LOD)
       dtxIx <- which(theObject$Y>transLOD)
       ndtxIx <- which(theObject$Y<=transLOD)

       theObject$dataPackage$yDetect <- theObject$Y[dtxIx]
       theObject$dataPackage$yNonDetect <- rep(NA,length(ndtxIx))
       theObject$dataPackage$detectIndex <- dtxIx
       theObject$dataPackage$nonDetectIndex <- ndtxIx
       theObject$dataPackage$NDetect <- length(dtxIx)
       theObject$dataPackage$NnonDetect <- length(ndtxIx)
       theObject$dataPackage$DETECTLIMIT <- transLOD

       
       yImpute <- theObject$initialImpute(theObject$Y[ndtxIx],theObject@LOD,theObject$transform)
       theObject$dataPackage$Y[ndtxIx] <- yImpute

       theObject$initPackage <- list(rtxmInitializeSamplerBasic(theObject,
          model=expression(Y~TaskMatrix+Z-1), extraProcessing=function(object,out){
            out$xi <- coef(object$initialModel)[-(1:object@nTasks)]    
            out     
          }
       ))
       theObject$initPackage[[1]]$yNonDetect <- yImpute
       theObject$dataPackage$Y <- NULL
              
       theObject$sampleAllVariables <- names(theObject$initPackage[[1]])
       theObject$sampleStandard <- setdiff(theObject$sampleAllVariables,"yNonDetect")

       # Added 1/19/2018 to implement setting of random number seed
       if(!is.null(theObject$.RNG.seed)) { 
          theObject$initPackage[[1]]$.RNG.name <- theObject$.RNG.name  
          theObject$initPackage[[1]]$.RNG.seed <- theObject$.RNG.seed 
       }  
       # End 1/19/2018 addition
     })
     if(inherits(catch,"try-error")) return(-2)

     return(-1)
   }
)

setMethod("plot",
          "rtxmBasicLODCovariatesModel",
   function(x, what, which=NULL, panels=3, col.lod="blue", lty.lod="cyan", pch.lod=19, ...){

     callNextMethod(x, what=what, which=which, panels=panels, ...)

     if(what==".obsvpred"){
         ndtxIx <- x$dataPackage$nonDetectIndex
         prCI <- x$predictionSummary$mu[,c("2.5%","97.5%")]
         for(i in ndtxIx){
            predi <- prCI[i,]
            lines(rep(x$Y[i],2), predi, col=col.lod)
         }
         points(x$Y[ndtxIx], x$predictionSummary$mu[ndtxIx,1], col=col.lod, pch=pch.lod)
     }
   }
)

