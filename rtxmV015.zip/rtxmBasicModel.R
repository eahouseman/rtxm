setMethod("initialize",
          "rtxmBasicModel",
     function(.Object, yResponse, xTask, data, timeSpline, gGroups=NULL, transform=function(u)as.vector(u),
       localfile=tempfile(),
       rng.seed=NULL, rng.name="base::Mersenne-Twister" # added 1/19/2018
      ){

        #####
        # 2016 Nov 1:  This step seems necessary to circumvent a tendency to
        #   overwrite the environment pointer to a default (same) environment across all S4 instances
        .Object@.xData=new.env()
        #####

        .Object@localfile=localfile
        sink(localfile)
        cat(.Object@jagsmodel)
        sink()

        .Object$.RNG.name <- rng.name  # added 1/19/2018
        .Object$.RNG.seed <- rng.seed  # added 1/19/2018

        n <- dim(data)[1]

        .Object$transform <- transform
        .Object$Y <- model.frame(yResponse, data, na.action=na.pass)
        if(dim(.Object$Y)[2] !=1 ) stop("yResponse formula must have only one variable.")

          .Object$X <- model.frame(xTask, data, na.action=na.pass)
          if(dim(.Object$X)[2] !=1 ) stop("xTask formula must have only one variable.")

          if(is.null(gGroups)){
            .Object$G <- data.frame(`G`=rep(1,n))
          }
          else{
            .Object$G <- model.frame(gGroups, data, na.action=na.pass)
          }

          miss <- is.na(.Object$Y[,1]) | is.na(.Object$X[,1])
          for(j in 1:dim(.Object$G)[2]) miss <- miss | is.na(.Object$G[,j])

          if(any(miss)){
             obs <- .Object$originalDataUsed <- which( !miss )
             .Object$Y <- .Object$Y[obs,,drop=FALSE]
             .Object$X <- .Object$X[obs,,drop=FALSE]
             .Object$G <- .Object$G[obs,,drop=FALSE]

             .Object$spline <- timeSpline$spline[obs,,drop=FALSE]
          }
          else {
            .Object$spline <- timeSpline$spline
            .Object$originalDataUsed <- 1:n
          }

          .Object$Y <- transform(.Object$Y[,1])
          .Object$X <- as.factor(.Object$X[,1])

          .Object@knots <- timeSpline$knots
          .Object@boundary <- timeSpline$knotBoundary
          .Object@times <- timeSpline$times

          .Object@nObservations <- length(.Object$originalDataUsed)

          .Object$TaskMatrix <- model.matrix(~.Object$X-1)
          .Object@nTasks <- dim(.Object$TaskMatrix)[2]
          colnames(.Object$TaskMatrix) <- levels(.Object$X)

          rtxmMakeIndices(.Object@nObservations, expression(G[,1]), "index1", .Object)

          .Object$sampleHistory <- list()
          .Object$sampleVarIndex <- list()
          .Object$sampleN <- numeric(0)
          .Object$sampleThin <- numeric(0)

          .Object$status <- -2
          .Object
       }
)

rtxmDataPackageBasic <- function(object){
  list(
    Nsample = object@nObservations,
    Nprofile = object$index1$n,
    Ntask = object@nTasks,

    idProfile = object$index1$reverse,
    idTask = as.numeric(object$X),

    Y = object$Y,
    spline = object$spline,
    task = object$TaskMatrix[,-1],

    D = dim(object$spline)[2],
    P = object@nTasks-1,

    BETAPRECISION = as.vector(object@hyperparameters["BETAPRECISION"]),
    BETA0PRECISION = as.vector(object@hyperparameters["BETA0PRECISION"])
  )
}

rtxmInitializeSamplerBasic <- function(object, 
   model=expression(Y~TaskMatrix-1), extraProcessing=NULL){
   object$initialModel <- model
   object$initialModel <- with(object, lm(eval(initialModel)))

   # Implied means for each task
   tmpMeanTask <- coef(object$initialModel)[1:object@nTasks] 

   # Implied grand intercept
   tmpBeta0 <- tmpMeanTask[1]  
      
   # Implied task differences
   tmpBetas <- tmpMeanTask[-1]-tmpMeanTask[1] 

   tmpZetas <- matrix(0,object$index1$n,dim(object$spline)[2])

   tmpSigmaSq <- summary(object$initialModel)$sigma^2
   tmpSigmaSqE <- tapply(resid(object$initialModel), 
      as.numeric(object$X), var, na.rm=TRUE)
   tmpSigmaSqE[is.na(tmpSigmaSqE)] <- tmpSigmaSq

   tmpSigmaSqZ <- tmpSigmaSq/10000

   out <- list(
    beta0 = tmpBeta0,
    beta = tmpBetas,
    zeta = tmpZetas,
    tauZ = 1/tmpSigmaSqZ,
    tauE  = 1/tmpSigmaSqE
   )
   if(!is.null(extraProcessing)){
      out <- extraProcessing(object,out)
   }
   out
}    

rtxmSamplerPostProcessBasic  <- function(object, which){

  sampVarNames <- colnames(object$sampleHistory[[which]][[1]])
  varIndex <- list()

  varIndex$intercept <- grep("beta0",sampVarNames) 
  names(varIndex$intercept) <- colnames(object$TaskMatrix)[1]

  varIndex$coefficients <- grep("beta[[]",sampVarNames)
  names(varIndex$coefficients) <- colnames(object$TaskMatrix)[-1]

  varIndex$precisionEps <- grep("tauE[[]",sampVarNames)
  names(varIndex$precisionEps) <- colnames(object$TaskMatrix)

  varIndex$precisionZeta <- grep("tauZ",sampVarNames) 

  varIndex$zeta <- array(grep("zeta[[]",sampVarNames), 
    dim=c(object$index1$n, dim(object$spline)[2]))

  rownames(varIndex$zeta) <- names(object$index1$forward)
  
  object$sampleVarIndex[[which]] <- varIndex
}

rtxmSamplerPrintBasic  <- function(object, extraInfo=NULL){
     cat(object@description,"\n\n")
     cat("Observations:",object@nObservations,"\n")
     cat("Tasks:",object@nTasks,"\n")
     cat("Profiles:", object$index1$n,"\n\nHyperparameters:\n")
     print(object@hyperparameters)
     cat("\nSpline basis functions:", dim(object$spline)[2],"\n")
     cat("Spline boundary:", object@boundary,"\n")
     cat("Knots: n=", length(object@knots), ", density in support: ", 
         1/median(diff(object@knots)*24)," per hour\n\n", sep="")

     if(!is.null(extraInfo)){
        extraInfo(object)
     }

     cat("Local file containing model definition:", object@localfile,"\n\n")
     cat("Markov-Chain Monte-Carlo status:",rtxmEvaluateSamplerStatus(object$status),"\n")
     if(object$status>=0) cat("Markov-Chain Monte-Carlo burn-in:",object$sampleN[1],"\n")

     if(object$status>=1) {
       cat("\nSample history:\n")

       tmpv <- lapply(object$sampleHistory, function(o){
           unique(gsub("[[][[:print:]]*$","",colnames(o[[1]])))
       })
     
       print(data.frame(`N`=object$sampleN[-1],`thin`=object$sampleThin[-1],
         `variables`=sapply(tmpv,paste,collapse=",")))
    }
  }

rtxmPlotBasicObsVPred <- function(x, which, 
   xlab="Observed", ylab="Expected", pch=1, 
   col.line="red", col.dot="black", col.interval="lightgray"){

     pr <- predict(x, which=which)
     plot(x$Y, pr[,1], type="n", xlab=xlab, ylab=ylab)

     prCI <- pr[,c("2.5%","97.5%")]
     for(i in 1:x@nObservations){
        predi <- prCI[i,]
        lines(rep(x$Y[i],2), predi, col=col.interval)
     }
      
     points(x$Y, pr[,1], col=col.dot, pch=pch)
     abline(0,1,col=col.line)
}

rtxmPlotBasicTraceDist <- function(x, what, which, panels=3, ...){
    xfuntag <- gsub("^[.][[:alpha:]]*[.]","", what[1])
    pfuntag <- gsub("[.][[:alpha:]]*$","", what[1])
    xfun <- list(
      `tasks`=expression( getTaskMeans(x, which=which) ), 
      `sdEpsilon`=expression( getVarianceComponents(x, "epsilon", which=which) ), 
      `sdZeta`=expression( getVarianceComponents(x, "zeta", which=which) ), 
      `coefs`=expression({
           o <- cbind(getIntercept(x,which=which),getCoefficients(x, which=which))
           colnames(o)[1] <- "(Intercept)"
           o
      }))[[xfuntag]]
    pfun <- list(
      `.trace`=expression( rtxmTracePlot(xm, panels, ...) ),
      `.density`=expression( rtxmDensityPlot(xm, panels, ...) )
    )[[pfuntag]]
    xm <- eval(xfun)
    eval(pfun)
}

setMethod("adaptivate",
          "rtxmBasicModel",
   function(theObject){
     catch <- try({

       theObject$dataPackage <- rtxmDataPackageBasic(theObject)
       theObject$initPackage <- list(rtxmInitializeSamplerBasic(theObject))
       theObject$sampleAllVariables <- names(theObject$initPackage[[1]])
       theObject$sampleStandard <- theObject$sampleAllVariables

       # Added 1/19/2018 to implement setting of random number seed
       if(!is.null(theObject$.RNG.seed)) { 
          theObject$initPackage[[1]]$.RNG.name <- theObject$.RNG.name  
          theObject$initPackage[[1]]$.RNG.seed <- theObject$.RNG.seed 
       }  
       # End 1/19/2018 addition

     })
     if(inherits(catch,"try-error")) return(-2)

     return(-1)
   }
)

setMethod("postprocess",
          "rtxmBasicModel",
   function(theObject){
      rtxmSamplerPostProcessBasic(theObject, theObject$status)
      theObject$status+1
   }
)

setMethod("getVariableBlock",
          "rtxmBasicModel",
   function(theObject, whichBlock, which=NULL, vindex=NULL, vsubRow=NULL, vsubCol=NULL){
     if(is.null(which)) which <- theObject$status-1
     if(is.null(vindex)) vindex <- theObject$sampleVarIndex[[which]]

     vv <- vindex[[whichBlock]]
     if(!is.null(vsubRow)) {
        vv <- vv[vsubRow,]
        if(!is.null(vsubCol)) vv <- vv[vsubCol]
     }
     else if(!is.null(vsubCol)){
        vv <- vv[,vsubCol]
     }

     o <- theObject$sampleHistory[[which]][[1]][,vv,drop=FALSE]
     if(is.matrix(o)) colnames(o) <- names(vv)
     o
   }
)

setMethod("getIntercept",
          "rtxmBasicModel",
   function(theObject, which=NULL, vindex=NULL){
     getVariableBlock(theObject,whichBlock="intercept",
       which=which,vindex=vindex)
   }
)

setMethod("getCoefficients",
          "rtxmBasicModel",
   function(theObject, which=NULL, vindex=NULL){
     getVariableBlock(theObject,"coefficients",
         which=which,vindex=vindex)
   }
)

setMethod("getTaskMeans",
          "rtxmBasicModel",
   function(theObject, which=NULL, vindex=NULL){
     icpt <- getVariableBlock(theObject,whichBlock="intercept",
       which=which,vindex=vindex)
     coefs <- getVariableBlock(theObject,"coefficients",
         which=which,vindex=vindex)[,1:(theObject@nTasks-1)]
     out <- cbind(icpt, sweep(coefs,1,icpt,"+"))
     colnames(out)[1] <- levels(theObject$X)[1]
     out
   }
)

setMethod("getVarianceComponents",
          "rtxmBasicModel",
   function(theObject, whichComponent, which=NULL, vindex=NULL, precisionToSD=TRUE){
     tag <- c(`epsilon`="precisionEps", `zeta`="precisionZeta")[whichComponent]
     if(is.na(tag)) tag <- whichComponent 
     o <- getVariableBlock(theObject,tag,which=which,vindex=vindex)  
     if(precisionToSD) o <- 1/sqrt(o)
     o
   }
)

setMethod("getZetaCoefficients","rtxmBasicModel",
   function(theObject, whichComponent, which=NULL, vindex=NULL){
    zeta1 <- getVariableBlock(theObject,"zeta",which=which,vindex=vindex,vsubRow=1)
    zetas <- array(NA, dim=c(theObject$index1$n,dim(zeta1)))
    zetas[1,,] <- zeta1
    if(theObject$index1$n>1) for(i in 2:theObject$index1$n){
        zetas[i,,] <- getVariableBlock(theObject,"zeta",which=which,vindex=vindex,vsubRow=i)
    }
    dimnames(zetas)[[1]] <- names(theObject$index1$forward)
    zetas
})

setMethod("getPredictions",
          "rtxmBasicModel",
   function(theObject, whichComponent, which=NULL, vindex=NULL, level=1){
      if(is.null(which)) which <- theObject$status-1

      # Check to see if they've been calculated already
      if(!is.null(theObject$predictions)){ 
          if(theObject$predictions$which == which) 
             return(theObject$predictions$mu)
      }

      # If not, calculate and save them
      v <- theObject$sampleVarIndex[[which]]

      dsgn <- cbind(1,theObject$dataPackage$task)
      beta <- rbind(
         t(getIntercept(theObject, which=which, vindex=v)),
         t(getCoefficients(theObject, which=which, vindex=v))
      )
      sampMu <- dsgn %*% beta 
      if(level>=1){
        for(i in 1:theObject$index1$n){
          zeta <- getVariableBlock(theObject,"zeta",which=which,vindex=vindex,vsubRow=i)
          ii <- theObject$index1$forward[[i]]
          sampMu[ii,] <- sampMu[ii,]+ theObject$spline[ii,] %*% t(zeta) 
        }
      }
      theObject$predictions <- list(which=which, mu=sampMu)
      sampMu     
   }
)

setMethod("update",
          "rtxmBasicModel",
   function(object, nSamples=100, variables=NULL, nThin=1){
      rtxmStandardUpdater(object, nSamples=nSamples, 
         variables=variables, nThin=nThin)
   }
)

setMethod("show", signature="rtxmBasicModel",
  definition=function(object){
     rtxmSamplerPrintBasic(object)
  }
)

setMethod("summary",
          "rtxmBasicModel",
   function(object, which=NULL){
     if(is.null(which)) which <- object$status-1
     v <- object$sampleVarIndex[[which]]
 
     out1 <- rbind(
       rtxmStandardPosterior(getIntercept(object, which=which, vindex=v)),
       t(apply(getCoefficients(object, which=which, vindex=v),
          2,rtxmStandardPosterior))
     )
     rownames(out1)[1] <- "(Intercept)"

     out2 <- t(apply(getVarianceComponents(object, "epsilon", which=which, vindex=v),2,
       rtxmStandardPosterior, stats=c(0.025,0.5,0.975)))

     out3 <- rtxmStandardPosterior(
          getVarianceComponents(object, "zeta", which=which, vindex=v),
          stats=c(0.025,0.5,0.975))

     list(`fixed effects`=out1, `task standard deviations`=out2, `zeta standard deviation`=out3)
   }
)

setMethod("predict",
          "rtxmBasicModel",
   function(object, which=NULL){
      # Check to see if they've been calculated already
      if(is.null(which)) which <- object$status-1

      if(!is.null(object$predictionSummary)){ 
          if(object$predictionSummary$which == which) 
             return(object$predictionSummary$mu)
      }

      # If not, calculate and save them
      pr <- t(apply(getPredictions(object, which=which),1,rtxmStandardPosterior))
      object$predictionSummary <- list(which=which, mu=pr)
      pr
  }
)


setMethod("plot",
          "rtxmBasicModel",
   function(x, what, which=NULL, panels=3, ...){

    if(what==".obsvpred"){
        rtxmPlotBasicObsVPred(x, which, ...)
    }
    else {
       rtxmPlotBasicTraceDist(x, what, which, panels=panels, ...)
    }
  }
)

setMethod("showJAGS",
          "rtxmBasicModel",
   function(theObject){
    cat(theObject@jagsmodel,"\n")
})
