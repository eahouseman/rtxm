rtxmBasicModel <- setClass(
  "rtxmBasicModel",
  contains = "environment",
  slots=c(
    description="character",
    jagsmodel="character",
    localfile="character",
    knots="numeric",
    boundary="numeric",
    times="numeric",
    nObservations="numeric",
    nTasks="numeric",
    hyperparameters="numeric"
  ),
  prototype=list(
    description="Basic Model for real-time exposure monitoring\n(No covariates, no nondetects)",
    jagsmodel=.rtxmBASICMODELDEFINITIONS["BASIC"], 
     localfile="", knots=numeric(0), boundary=numeric(0), 
     nObservations=0, nTasks=0,
     hyperparameters=c(`BETAPRECISION` = 0.0001,`BETA0PRECISION` = 0.0001)
  )
)

rtxmBasicCovariatesModel <- setClass(
  "rtxmBasicCovariatesModel",
  contains = "rtxmBasicModel",
  slots=c(nCovariates="numeric"),
  prototype=list(
    description="Basic Model for real-time exposure monitoring\n(Covariates, no nondetects)",
    jagsmodel=.rtxmBASICMODELDEFINITIONS["BASICWCOVARIATES"],
    nCovariates=0)
)

rtxmBasicLODModel <- setClass(
  "rtxmBasicLODModel",
  contains = "rtxmBasicModel",
  slots=c(LOD="numeric"),
  prototype=list(
    description="Basic Model for real-time exposure monitoring\n(Nondetects, no covariates)",
    jagsmodel=.rtxmBASICMODELDEFINITIONS["BASICLOD"],
    LOD=0)
)

rtxmBasicLODCovariatesModel <- setClass(
  "rtxmBasicLODCovariatesModel",
  contains = "rtxmBasicCovariatesModel",
  slots=c(LOD="numeric"),
  prototype=list(
    description="Basic Model for real-time exposure monitoring\n(Nondetects, covariates)",
    jagsmodel=.rtxmBASICMODELDEFINITIONS["BASICLODWCOVARIATES"],
    LOD=0)
)

rtxmBasicProfileREffModel <- setClass(
  "rtxmBasicProfileREffModel",
  contains = "rtxmBasicModel",
  prototype=list(
    description="Model for real-time exposure monitoring\n(Random profile effect, No covariates, no nondetects)",
    jagsmodel=.rtxmBASICMODELDEFINITIONS["BASIC_PROFILEREFF"])
)


rtxmProfileREffCovariatesModel <- setClass(
  "rtxmProfileREffCovariatesModel",
  contains = "rtxmBasicCovariatesModel",
  slots=c(nCovariates="numeric"),
  prototype=list(
    description="Model for real-time exposure monitoring\n(Random profile effect, Covariates, no nondetects)",
    jagsmodel=.rtxmBASICMODELDEFINITIONS["PROFILEREFF_WCOVARIATES"])
)

rtxmProfileREffLODModel <- setClass(
  "rtxmProfileREffLODModel",
  contains = "rtxmBasicLODModel",
  slots=c(LOD="numeric"),
  prototype=list(
    description="Model for real-time exposure monitoring\n(Random profile effect, Nondetects, no covariates)",
    jagsmodel=.rtxmBASICMODELDEFINITIONS["PROFILEREFF_LOD"])
)

rtxmProfileREffLODCovariatesModel <- setClass(
  "rtxmProfileREffLODCovariatesModel",
  contains = "rtxmBasicLODCovariatesModel",
  slots=c(LOD="numeric"),
  prototype=list(
    description="Model for real-time exposure monitoring\n(Random profile effect, Nondetects, covariates)",
    jagsmodel=.rtxmBASICMODELDEFINITIONS["PROFILEREFF_LODWCOVARIATES"])
)

### Added 13 June 2018 to address multiple LODs

rtxmBasicLODsModel <- setClass(
  "rtxmBasicLODsModel",
  contains = "rtxmBasicModel",
  prototype=list(
    description="Basic Model for real-time exposure monitoring\n(Nondetects, variable LODs, no covariates)",
    jagsmodel=.rtxmBASICMODELDEFINITIONS["BASICLODS"])
)

rtxmBasicLODsCovariatesModel <- setClass(
  "rtxmBasicLODsCovariatesModel",
  contains = "rtxmBasicCovariatesModel",
  prototype=list(
    description="Basic Model for real-time exposure monitoring\n(Nondetects, variable LODs, covariates)",
    jagsmodel=.rtxmBASICMODELDEFINITIONS["BASICLODSWCOVARIATES"])
)

rtxmProfileREffLODsModel <- setClass(
  "rtxmProfileREffLODsModel",
  contains = "rtxmBasicLODsModel",
  prototype=list(
    description="Model for real-time exposure monitoring\n(Random profile effect, Nondetects, variable LODs, no covariates)",
    jagsmodel=.rtxmBASICMODELDEFINITIONS["PROFILEREFF_LODS"])
)

rtxmProfileREffLODsCovariatesModel <- setClass(
  "rtxmProfileREffLODsCovariatesModel",
  contains = "rtxmBasicLODsCovariatesModel",
  prototype=list(
    description="Model for real-time exposure monitoring\n(Random profile effect, Nondetects, variable LODs, covariates)",
    jagsmodel=.rtxmBASICMODELDEFINITIONS["PROFILEREFF_LODSWCOVARIATES"])
)

