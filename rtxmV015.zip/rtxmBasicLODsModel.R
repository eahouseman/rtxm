setMethod("initialize",
          "rtxmBasicLODsModel",
     function(.Object, yResponse, xTask, data, timeSpline, LOD, gGroups=NULL, 
        transform=function(u)as.vector(u), initialImpute=NULL, localfile=tempfile(),
          rng.seed=NULL, rng.name="base::Mersenne-Twister" # added 1/19/2018
      ){
        .Object <- callNextMethod(.Object, yResponse, xTask, data=data, 
           timeSpline=timeSpline, gGroups=gGroups, transform=transform, localfile=localfile,
           rng.seed=rng.seed, rng.name=rng.name) # added 1/19/2018
 
        rtxmInitBasicLODsModel(.Object, LOD, initialImpute)
     }
)

rtxmInitBasicLODsModel <- function(.Object, LOD, initialImpute){

    if(all(.Object$Y>.Object$transform(LOD))) stop("All data are above detection; use basic model.\n")

    .Object$LOD <- LOD

    if(is.null(initialImpute)){
        .Object$initialImpute <- function(y,LOD,transform) {
            y[] <- .Object$transform(LOD/2)
            y
        }
     }
    else {
       .Object$initialImpute <- initialImpute
    }

    .Object
}

setMethod("show", signature="rtxmBasicLODsModel",
  definition=function(object){
     rtxmSamplerPrintBasic(object, function(o){
         sumLOD <- quantile(o$LOD,c(0.25,0.5,0.75))
         cat("Limits-of-detection: (",sumLOD[1],"-|", sumLOD[2],"|-", sumLOD[3],")\n")
         cat("Percent non-detect:",round(100*mean(o$Y<=o$transform(o$LOD)),1),"\n\n")
     })
  }
)

setMethod("adaptivate",
          "rtxmBasicLODsModel",
   function(theObject){
     catch <- try({

       theObject$dataPackage <- rtxmDataPackageBasic(theObject)

       transLOD <- theObject$transform(theObject$LOD)
       dtxIx <- which(theObject$Y>transLOD)
       ndtxIx <- which(theObject$Y<=transLOD)

       theObject$dataPackage$yDetect <- theObject$Y[dtxIx]
       theObject$dataPackage$yNonDetect <- rep(NA,length(ndtxIx))
       theObject$dataPackage$detectIndex <- dtxIx
       theObject$dataPackage$nonDetectIndex <- ndtxIx
       theObject$dataPackage$NDetect <- length(dtxIx)
       theObject$dataPackage$NnonDetect <- length(ndtxIx)

       theObject$dataPackage$detectLimit <- transLOD[ndtxIx]

       yImpute <- theObject$initialImpute(theObject$Y[ndtxIx],theObject$LOD[ndtxIx],theObject$transform)
       theObject$dataPackage$Y[ndtxIx] <- yImpute

       theObject$initPackage <- list(rtxmInitializeSamplerBasic(theObject))
       theObject$initPackage[[1]]$yNonDetect <- yImpute
       theObject$dataPackage$Y <- NULL

       theObject$sampleAllVariables <- names(theObject$initPackage[[1]])
       theObject$sampleStandard <- setdiff(theObject$sampleAllVariables,"yNonDetect")

       # Added 1/19/2018 to implement setting of random number seed
       if(!is.null(theObject$.RNG.seed)) { 
          theObject$initPackage[[1]]$.RNG.name <- theObject$.RNG.name  
          theObject$initPackage[[1]]$.RNG.seed <- theObject$.RNG.seed 
       }  
       # End 1/19/2018 addition
     })
     if(inherits(catch,"try-error")) return(-2)

     return(-1)
   }
)

setMethod("plot",
          "rtxmBasicLODsModel",
   function(x, what, which=NULL, panels=3, col.lod="blue", lty.lod="cyan", pch.lod=19, ...){

     callNextMethod(x, what=what, which=which, panels=panels, ...)

     if(what==".obsvpred"){
         ndtxIx <- x$dataPackage$nonDetectIndex
         prCI <- x$predictionSummary$mu[,c("2.5%","97.5%")]
         for(i in ndtxIx){
            predi <- prCI[i,]
            lines(rep(x$Y[i],2), predi, col=col.lod)
         }
         points(x$Y[ndtxIx], x$predictionSummary$mu[ndtxIx,1], col=col.lod, pch=pch.lod)
     }
   }
)

