rtxmParseDateTime <- function(dtString, formatString, outputDateFormat="%y-%m-%d"){
  DT <- strptime(dtString,formatString)

  time.days <- (DT$hour + (DT$min+DT$sec/60)/60)/24
  day.year <- DT$year+1900
  day.month <- DT$mon
  day.monthDay <- DT$mday
  day.yearDay <- DT$yday

  n <- length(dtString)
  out.date <- rep("",n)
  for(i in 1:n){
    out.date[i] <- gsub("[%]d",day.monthDay[i],
      gsub("[%]m",day.month[i]+1,gsub("[%]y",day.year[i],outputDateFormat)))
  }
  data.frame(date=out.date,day.year,day.month,
    day.monthDay,day.yearDay,time.days,stringsAsFactors=FALSE)
}

rtxmConvertTime <- function(times, unitsIn="days", unitsOut="minutes"){
   timeTransTable <- c(`days`=1, `hours`=24, `minutes`=1440, `seconds`=86400)
   (timeTransTable[unitsOut]/timeTransTable[unitsIn])*times
}

rtxmFindDuplicates <- function(x, profileID, times, 
   timeUnits="days", timeUnitsRecorded="minutes", delimit=":"){

   #Note: "timeUnitsRecorded" should be close to the unit of time used for recording
   #  (i.e. this conversion should result in values as close to 
   #     whole numbers as possible)
   times <- rtxmConvertTime(times, timeUnits, timeUnitsRecorded)
   
   readingStamp <- paste(profileID, times, sep=delimit)
   
   n <- length(x)
   index <- split(1:n, readingStamp)

   possibleDuplicates <- which(sapply(index,length)>1)
   if(length(possibleDuplicates)==0) return(list())

   index <- index[ possibleDuplicates ]
   v <- sapply(index, function(i) var(x[i]))
   possibleDuplicates <- which(v==0)

   if(length(possibleDuplicates)==0) return(list())
   return(index[possibleDuplicates])
}

rtxmFixDuplicates <- function(dupList, data){
   if(length(dupList)==0){
     warning("There are no duplicates to fix!")
     return(data)
   }
   destroy <- unlist(sapply(dupList,function(u)u[-1])) # Get all but the first index
   data[-destroy,]
}

rtxmGetKnots <- function(times, knotDensity=8, 
   unitsIn="days", unitsDensity="hours", quantiles=(1:999)/1000){
  qtile <- rtxmConvertTime(quantile(times, quantiles), unitsIn, unitsDensity)
  kn <- sort(unique(round(qtile*knotDensity)/knotDensity))
  rtxmConvertTime(kn, unitsDensity, unitsIn)
}

rtxmMakeBspline <- function(times, knotDensity=8, knotBoundary=c(0,24),
  unitsIn="days", unitsDensity="hours", quantiles=(1:999)/1000){

  knotBoundary <- rtxmConvertTime(knotBoundary, unitsDensity, unitsIn)
  knots <- rtxmGetKnots(times, knotDensity, unitsIn, unitsDensity, quantiles)
  sp <- bs(times, knots=knots, Boundary.knots=knotBoundary)
  list(spline=sp, knots=knots, knotBoundary=knotBoundary, times=times)
}

rtxmMakeIndices <- function(n, byExpr, indexName, env){
   ix <- indexName
   ixr <- paste(indexName,"reverse",sep="")
   ixn <- paste(indexName,"n",sep="")
   env[[ix]] <- list()
   env[[ix]]$forward <- split(1:n, eval(byExpr, env))
   env[[ix]]$n <- length(env[[ix]]$forward)

   env[[ix]]$reverse <- rep(0,n)
   for(i in 1:env[[ix]]$n){
      env[[ix]]$reverse[ env[[ix]]$forward[[i]] ] <- i
   }
}

##############################################################################################

rtxmStandardPosterior <- function(x, na.rm=FALSE, 
   stats=c(-1,-2,0.025,0.5,0.975)){
  out <- NULL
  if(-1 %in% stats){
    out <- c(out,`mean`=mean(x,na.rm=na.rm))
  }
  if(-2 %in% stats){
    out <- c(out,`sd`=sd(x,na.rm=na.rm))
  }
  stats <- stats[stats>=0]
  if(length(stats)>0){
    out <- c(out, quantile(x,stats))
  }
  out
}

rtxmStandardUpdater <- function(object, nSamples=100, variables=NULL, nThin=1){

      if(object$status <= -2){
         object$status <- adaptivate(object)
      }
      if(object$status == -1){
          object$sampler <- jags.model(object@localfile,
              object$dataPackage, object$initPackage, n.adapt=0)

         rtxmAdaptJAGS(object$sampler,nSamples)
         object$status <- 0
         object$sampleN[1] <- 0
         object$sampleThin[1] <- 0
      }
      else if(object$status == 0){

         if(!is.null(variables)) {
            if(object$sampleN[1]<100) warning(paste("# burn-in samples =",object$sampleN[1]))
            object$status <- 1
         }
         else {
            update(object$sampler, nSamples)
            object$sampleN[1] <- object$sampleN[1] + nSamples
         }
      }

      if(object$status>0){
         if(is.null(variables)) variables <- character(0)
         else if(variables=="$standard") variables <- object$sampleStandard  
         else if(variables=="$all") variables <- object$sampleAllVariables 

         object$sampleHistory[[ object$status ]] <- coda.samples(
            object$sampler, variables, n.iter=nSamples, thin=nThin)

         object$sampleN[ object$status + 1] <- nSamples
         object$sampleThin[ object$status + 1] <- nThin

         object$status <- postprocess(object)
      }
   }

rtxmAdaptJAGS <- function(jagsModel, increments=100){
  isAdapted <- FALSE
  adpCounter <- 0
  while(!isAdapted){
    isAdapted <- adapt(jagsModel,increments)
    adpCounter <- adpCounter+increments
    cat(adpCounter, isAdapted, "\n")
  }
  adpCounter
}

rtxmEvaluateSamplerStatus <- function(status){
  if(status<=0){
    return(c("uninitialized","initialized/adapting","adapted/burn-in")[status+3])
  }
  paste("sampling block",status-1)
}

rtxmPlotPanels <- function(x, panels, fun){
     if(!is.matrix(x)){
         x <- matrix(x, ncol=1)
     }
     
     d <- dim(x)[2]

     pn <- par()$mfrow
     op <- devAskNewPage()
     
     if(length(panels)==1) panels <- c(panels,1)

     nPanels <- prod(panels)
     if(d>nPanels){
        devAskNewPage(TRUE)
        par(mfrow=panels)
     }
     else {
       if(panels[2]==1) par(mfrow=c(d,1))
       else par(mfrow=panels)
     }
     for(i in 1:d){
        fun(x[,i], colnames(x)[i])
     }
     devAskNewPage(op)
     par(mfrow=pn)   
}

rtxmTracePlot <- function(x, panels, ...){
    rtxmPlotPanels(x, panels, function(x,label){
       n <- length(x)
       plot(1:n, x, type="l", xlab="sample", ylab="", main=label, ...)
    })
}

rtxmDensityPlot <- function(x, panels, ...){
    rtxmPlotPanels(x, panels, function(x,label){
       plot(density(x, ...), main=label)
    })
}

rtxmPlotProfile = function(object, profileIndex, which=NULL,
    xlab="time",ylab="",main=names(object@.xData$index1$forward)[profileIndex],
    fill="yellow",pch=19,col.line="red",col.point="black", ...){

  preds = predict(object, which=which)
  time = object@times
  Y=object@.xData$Y

  ix = object@.xData$index1$forward[[profileIndex]]
  ixR = ix[length(ix):1]

  plot(range(time[ix]), range(c(preds[ix,-2],Y[ix])), type="n", 
     xlab=xlab, ylab=ylab, main=main, ...)
  polygon(c(time[ixR],time[ix]),
        c(preds[ixR,"97.5%"],preds[ix,"2.5%"]),border=NA,col=fill)
  lines(time[ix],preds[ix,"mean"],lwd=2,col=col.line)
  points(time[ix], theData$lnY[ix],pch=pch,col=col.point)
}

setGeneric(name="adaptivate",
   def=function(theObject, ...)
   {
      standardGeneric("adaptivate")
   }
)

setGeneric(name="postprocess",
   def=function(theObject, ...)
   {
      standardGeneric("postprocess")
   }
)

setGeneric(name="getVariableBlock",
   def=function(theObject, ...)
   {
      standardGeneric("getVariableBlock")
   }
)

setGeneric(name="getIntercept",
   def=function(theObject, ...)
   {
      standardGeneric("getIntercept")
   }
)

setGeneric(name="getCoefficients",
   def=function(theObject, ...)
   {
      standardGeneric("getCoefficients")
   }
)

setGeneric(name="getTaskMeans",
   def=function(theObject, ...)
   {
      standardGeneric("getTaskMeans")
   }
)

setGeneric(name="getVarianceComponents",
   def=function(theObject, ...)
   {
      standardGeneric("getVarianceComponents")
   }
)

setGeneric(name="getPredictions",
   def=function(theObject, ...)
   {
      standardGeneric("getPredictions")
   }
)

setGeneric(name="getZetaCoefficients",
   def=function(theObject, ...)
   {
      standardGeneric("getZetaCoefficients")
   }
)

setGeneric(name="showJAGS",
   def=function(theObject, ...)
   {
      standardGeneric("showJAGS")
   }
)

##############################################################################################

source("rtxmBasicModel.R")
source("rtxmBasicCovariatesModel.R")
source("rtxmBasicLODModel.R")
source("rtxmBasicLODCovariatesModel.R")

source("rtxmBasicProfileREffModel.R")
source("rtxmProfileREffCovariatesModel.R")
source("rtxmProfileREffLODModel.R")
source("rtxmProfileREffLODCovariatesModel.R")

### Added 13 June 2018 to address multiple LODs

source("rtxmBasicLODsModel.R")
source("rtxmBasicLODsCovariatesModel.R")
source("rtxmProfileREffLODsModel.R")
source("rtxmProfileREffLODsCovariatesModel.R")
