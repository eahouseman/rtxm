setMethod("adaptivate",
          "rtxmProfileREffLODsCovariatesModel",
   function(theObject){
      ret <- callNextMethod(theObject)
      if(ret < -1) return(ret)

      catch <- try({
        theObject$initPackage[[1]]$alpha <- rep(0, theObject$index1$n)
        theObject$initPackage[[1]]$tauA <- 0.1 * theObject$initPackage[[1]]$tauZ 

        # Changed 1/23/2018; delete random number seed specs from variable list
        #   (var list originally constructed from init list, which may have RNG specs)
        sampVars <- names(theObject$initPackage[[1]])
        theObject$sampleAllVariables <- setdiff(sampVars, c(".RNG.name",".RNG.seed"))

        theObject$sampleStandard <- theObject$sampleAllVariables
      }) 
     if(inherits(catch,"try-error")) return(-2)

     return(-1)      
   }

)

setMethod("postprocess",
          "rtxmProfileREffLODsCovariatesModel",
   function(theObject){
      s <- theObject$status

      rtxmSamplerPostProcessBasic(theObject, s)

      sampVarNames <- colnames(theObject$sampleHistory[[s]][[1]])

      theObject$sampleVarIndex[[s]]$precisionAlpha <- grep("tauA", sampVarNames)
      theObject$sampleVarIndex[[s]]$profileIntercepts <- grep("^alpha", sampVarNames)

      names(theObject$sampleVarIndex[[s]]$profileIntercepts) <- names(theObject$index1$forward)

      moreCoefs <- grep("^xi", colnames(theObject$sampleHistory[[s]][[1]]))
      names(moreCoefs) <- colnames(theObject$Z)
      theObject$sampleVarIndex[[s]]$coefficients2 <- moreCoefs

      theObject$status+1
   }
)

setMethod("getCoefficients",
          "rtxmProfileREffLODsCovariatesModel",
   function(theObject, which=NULL, vindex=NULL, whichSet="fixed"){
     if(whichSet=="task"){
       getVariableBlock(theObject,"coefficients",
           which=which,vindex=vindex)
     }
     else if(whichSet=="covariates"){
       getVariableBlock(theObject,"coefficients2",
           which=which,vindex=vindex)
     }
     else if(whichSet=="profileIntercepts"){
       getVariableBlock(theObject,"profileIntercepts",
           which=which,vindex=vindex)
     }
     else if(whichSet=="fixed"){
       cbind(
         getVariableBlock(theObject,"coefficients",
             which=which,vindex=vindex),
         getVariableBlock(theObject,"coefficients2",
             which=which,vindex=vindex)
       )
     }
     else if(whichSet=="all"){
       cbind(
         getVariableBlock(theObject,"coefficients",
             which=which,vindex=vindex),
         getVariableBlock(theObject,"coefficients2",
             which=which,vindex=vindex),
         getVariableBlock(theObject,"profileIntercepts",
             which=which,vindex=vindex)
       )
     }
   }
)

setMethod("summary",
          "rtxmProfileREffLODsCovariatesModel",
   function(object, which=NULL){
     out <- callNextMethod(object, which=which)
     
     #moreEffects <- getCoefficients(object, which=which, whichSet="covariates")

     if(is.null(which)) which <- object$status-1
     v <- object$sampleVarIndex[[which]]

     out[["alpha standard deviation"]] <- rtxmStandardPosterior(
            getVarianceComponents(object, "precisionAlpha", which=which, vindex=v),
            stats=c(0.025,0.5,0.975))
     out
})


setMethod("getPredictions",
          "rtxmProfileREffLODsCovariatesModel",
   function(theObject, whichComponent, which=NULL, vindex=NULL, level=1){
      if(is.null(which)) which <- theObject$status-1

      # Check to see if they've been calculated already
      if(!is.null(theObject$predictions)){ 
          if(theObject$predictions$which == which) 
             return(theObject$predictions$mu)
      }

      # If not, calculate and save them
      v <- theObject$sampleVarIndex[[which]]

      if(level==0){
        dsgn <- cbind(1,theObject$dataPackage$task,theObject$Z)
        beta <- rbind(
          t(getIntercept(theObject, which=which, vindex=v)),
          t(getCoefficients(theObject, which=which, vindex=v, whichSet="fixed"))
        )
        sampMu <- dsgn %*% beta 
      }
      else {
        dsgn <- cbind(theObject$dataPackage$task,theObject$Z)
        beta <- t(getCoefficients(theObject, which=which, vindex=v, whichSet="fixed"))
        sampMu <- dsgn %*% beta 
      }

      if(level>=1){
        alpha <- getCoefficients(theObject, which=which, vindex=v, whichSet="profileIntercepts")
        for(i in 1:theObject$index1$n){
          zeta <- getVariableBlock(theObject,"zeta",which=which,vindex=vindex,vsubRow=i)

          ii <- theObject$index1$forward[[i]]
          sampMu[ii,] <- sampMu[ii,]+ theObject$spline[ii,] %*% t(zeta) 
          sampMu[ii,] <- sweep(sampMu[ii,],2,alpha[,i],"+")
        }
      }
      theObject$predictions <- list(which=which, mu=sampMu)
      sampMu 
   }
)


setMethod("plot",
          "rtxmProfileREffLODsCovariatesModel",
   function(x, what, which=NULL, panels=3, col.lod="blue", lty.lod="cyan", pch.lod=19, ...){

     if(what==".obsvpred"){
        rtxmPlotBasicObsVPred(x, which, ...)

        ndtxIx <- x$dataPackage$nonDetectIndex
        prCI <- x$predictionSummary$mu[,c("2.5%","97.5%")]
        for(i in ndtxIx){
           predi <- prCI[i,]
           lines(rep(x$Y[i],2), predi, col=col.lod)
        }
        points(x$Y[ndtxIx], x$predictionSummary$mu[ndtxIx,1], col=col.lod, pch=pch.lod)

     }
     else {
        rtxmPlotBasicREffTraceDist(x, what, which, panels=panels, ...)
     }
   }
)
