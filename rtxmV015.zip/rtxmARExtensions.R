######### AR-1 ZETAS

.rtxmAREXTENSIONSMODELDEFINITIONS <- c(
  `PROFILEREFF_WCOVARIATES`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)
        tauA ~ dnorm(0,1.0E-6)T(0,1.0E10)
        rho ~ dunif(-0.9999,0.9999)
        tauZinnovation <- tauZ / (1-rho*rho)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          zeta[it,1] ~ dnorm(0, tauZ)
          zetaInnovation[it,1] ~ dnorm(0, tauZinnovation)
          for(j in 2:D){
            zetaInnovation[it,j] ~ dnorm(0, tauZinnovation)
            zeta[it,j] <- zeta[it,j-1]*rho + zetaInnovation[it,j]
          }
          alpha[it] ~ dnorm(beta0, tauA)
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muTask[h] <-  alpha[idProfile[h]] + inprod(task[h,1:P],beta[1:P])
          muExtra[h] <- inprod(covariates[h,1:nCovariates], xi[1:nCovariates])
          mu[h] <-  muTimedep[h] + muTask[h] + muExtra[h]
          Y[h] ~ dnorm(mu[h], tauE[idTask[h]])
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(r in 1:nCovariates){
          xi[r] ~ dnorm(0,XIPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  ",
  `PROFILEREFF_LODSWCOVARIATES`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)
        tauA ~ dnorm(0,1.0E-6)T(0,1.0E10)
        rho ~ dunif(-0.9999,0.9999)
        tauZinnovation <- tauZ / (1-rho*rho)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          zeta[it,1] ~ dnorm(0, tauZ)
          zetaInnovation[it,1] ~ dnorm(0, tauZinnovation)
          for(j in 2:D){
            zetaInnovation[it,j] ~ dnorm(0, tauZinnovation)
            zeta[it,j] <- zeta[it,j-1]*rho + zetaInnovation[it,j]
          }
          alpha[it] ~ dnorm(beta0, tauA)
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muExtra[h] <- inprod(covariates[h,1:nCovariates], xi[1:nCovariates])
          muTask[h] <-  alpha[idProfile[h]] + inprod(task[h,1:P],beta[1:P])
          mu[h] <-  muTimedep[h] + muTask[h] + muExtra[h]
        }

        for(g1 in 1:NDetect){
          yDetect[g1] ~ dnorm(mu[detectIndex[g1]], tauE[idTask[detectIndex[g1]]])
        }

        for(g0 in 1:NnonDetect){
          yNonDetect[g0] ~ dnorm(mu[nonDetectIndex[g0]], tauE[idTask[nonDetectIndex[g0]]])
          isDetectND[g0] ~ dinterval(yNonDetect[g0] , detectLimit[g0])
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(r in 1:nCovariates){
          xi[r] ~ dnorm(0,XIPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
   ",
  `BASICLODSWCOVARIATES`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)
        rho ~ dunif(-0.9999,0.9999)
        tauZinnovation <- tauZ / (1-rho*rho)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          zeta[it,1] ~ dnorm(0, tauZ)
          zetaInnovation[it,1] ~ dnorm(0, tauZinnovation)
          for(j in 2:D){
            zetaInnovation[it,j] ~ dnorm(0, tauZinnovation)
            zeta[it,j] <- zeta[it,j-1]*rho + zetaInnovation[it,j]
          }
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muExtra[h] <- inprod(covariates[h,1:nCovariates], xi[1:nCovariates])
          muTask[h] <-  beta0 + inprod(task[h,1:P],beta[1:P])
          mu[h] <-  muTimedep[h] + muTask[h] + muExtra[h]
        }

        for(g1 in 1:NDetect){
          yDetect[g1] ~ dnorm(mu[detectIndex[g1]], tauE[idTask[detectIndex[g1]]])
        }

        for(g0 in 1:NnonDetect){
          yNonDetect[g0] ~ dnorm(mu[nonDetectIndex[g0]], tauE[idTask[nonDetectIndex[g0]]])
          isDetectND[g0] ~ dinterval(yNonDetect[g0] , detectLimit[g0])
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(r in 1:nCovariates){
          xi[r] ~ dnorm(0,XIPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  ",
  `BASICWCOVARIATES`=
      "model{
        tauZ ~ dnorm(0,1.0E-6)T(0,1.0E10)
        rho ~ dunif(-0.9999,0.9999)
        tauZinnovation <- tauZ / (1-rho*rho)

        beta0 ~ dnorm(0,BETA0PRECISION)

        for(it in 1:Nprofile){
          zeta[it,1] ~ dnorm(0, tauZ)
          zetaInnovation[it,1] ~ dnorm(0, tauZinnovation)
          for(j in 2:D){
            zetaInnovation[it,j] ~ dnorm(0, tauZinnovation)
            zeta[it,j] <- zeta[it,j-1]*rho + zetaInnovation[it,j]
          }
        }

        for(h in 1:Nsample){
          muTimedep[h] <- inprod(spline[h,1:D],zeta[idProfile[h],1:D])
          muTask[h] <-  beta0 + inprod(task[h,1:P],beta[1:P])
          muExtra[h] <- inprod(covariates[h,1:nCovariates], xi[1:nCovariates])
          mu[h] <-  muTimedep[h] + muTask[h] + muExtra[h]
          Y[h] ~ dnorm(mu[h], tauE[idTask[h]])
        }

        for(l in 1:P){
          beta[l] ~ dnorm(0,BETAPRECISION)
        }

        for(r in 1:nCovariates){
          xi[r] ~ dnorm(0,XIPRECISION)
        }

        for(k in 1:Ntask){
           tauE[k] ~ dnorm(0,1.0E-6)T(0,1.0E10)
        }
      }
  ")

rtxmProfileREffLODsCovariatesModelAR1Zeta <- setClass(
  "rtxmProfileREffLODsCovariatesModelAR1Zeta",
  contains = "rtxmProfileREffLODsCovariatesModel",
  prototype=list(
    description="Model for real-time exposure monitoring
(Random profile effect, Nondetects, variable LODs, covariates, AR-1 zeta covariance)",
    jagsmodel=.rtxmAREXTENSIONSMODELDEFINITIONS["PROFILEREFF_LODSWCOVARIATES"])
)

rtxmProfileREffCovariatesModelAR1Zeta <- setClass(
  "rtxmProfileREffCovariatesModelAR1Zeta",
  contains = "rtxmProfileREffCovariatesModel",
  prototype=list(
    description="Model for real-time exposure monitoring
(Random profile effect, Nondetects, covariates, AR-1 zeta covariance)",
    jagsmodel=.rtxmAREXTENSIONSMODELDEFINITIONS["PROFILEREFF_WCOVARIATES"])
)

rtxmBasicLODsCovariatesModelAR1Zeta <- setClass(
  "rtxmBasicLODsCovariatesModelAR1Zeta",
  contains = "rtxmBasicLODsCovariatesModel",
  prototype=list(
    description="Model for real-time exposure monitoring\n(Nondetects, variable LODs, covariates, AR-1 zeta covariance)",
    jagsmodel=.rtxmAREXTENSIONSMODELDEFINITIONS["BASICLODSWCOVARIATES"])
)

rtxmBasicCovariatesModelAR1Zeta <- setClass(
  "rtxmBasicCovariatesModelAR1Zeta",
  contains = "rtxmBasicCovariatesModel",
  prototype=list(
    description="Model for real-time exposure monitoring\n(Nondetects, covariates, AR-1 zeta covariance)",
    jagsmodel=.rtxmAREXTENSIONSMODELDEFINITIONS["BASICWCOVARIATES"])
)

rtxmAR1ZetaAdaptivateEngine <- function(theObject){
      catch <- try({
        theObject$initPackage[[1]]$zetaInnovation <- theObject$initPackage[[1]]$zeta
        theObject$initPackage[[1]]$zeta <- NULL

        theObject$initPackage[[1]]$rho <- 0
        theObject$sampleStandard <- c(theObject$sampleStandard,"rho")

      }) 
     if(inherits(catch,"try-error")) return(-2)

     return(-1) 
}

setMethod("adaptivate",
          "rtxmProfileREffLODsCovariatesModelAR1Zeta",
   function(theObject){
      ret <- callNextMethod(theObject)
      if(ret < -1) return(ret)
      rtxmAR1ZetaAdaptivateEngine(theObject)
   }
)

setMethod("adaptivate",
          "rtxmProfileREffCovariatesModelAR1Zeta",
   function(theObject){
      ret <- callNextMethod(theObject)
      if(ret < -1) return(ret)
      rtxmAR1ZetaAdaptivateEngine(theObject)  
   }
)


setMethod("adaptivate",
          "rtxmBasicLODsCovariatesModelAR1Zeta",
   function(theObject){
      ret <- callNextMethod(theObject)
      if(ret < -1) return(ret)
      rtxmAR1ZetaAdaptivateEngine(theObject)      
   }
)


setMethod("adaptivate",
          "rtxmBasicCovariatesModelAR1Zeta",
   function(theObject){
      ret <- callNextMethod(theObject)
      if(ret < -1) return(ret)
      rtxmAR1ZetaAdaptivateEngine(theObject)  
   }
)

rtxmAR1ZetaPostProcessEngine <- function(theObject){
   s <- length(theObject$sampleVarIndex)
   theObject$sampleVarIndex[[s]]$rho <- grep("rho", colnames(theObject$sampleHistory[[s]][[1]]))
   theObject$status+1
}

setMethod("postprocess",
          "rtxmProfileREffLODsCovariatesModelAR1Zeta",
   function(theObject){
      callNextMethod(theObject)
      rtxmAR1ZetaPostProcessEngine(theObject)
   }
)

setMethod("postprocess",
          "rtxmProfileREffCovariatesModelAR1Zeta",
   function(theObject){
      callNextMethod(theObject)
      rtxmAR1ZetaPostProcessEngine(theObject)
   }
)

setMethod("postprocess",
          "rtxmBasicCovariatesModelAR1Zeta",
   function(theObject){
      callNextMethod(theObject)
      rtxmAR1ZetaPostProcessEngine(theObject)
   }
)

setMethod("postprocess",
          "rtxmBasicLODsCovariatesModelAR1Zeta",
   function(theObject){
      callNextMethod(theObject)
      rtxmAR1ZetaPostProcessEngine(theObject)
   }
)

rtxmAR1ZetaSummaryEngine <- function(object, out, which){
   v <- object$sampleVarIndex[[which]]
   out[["zeta AR-1 parameter"]] <- rtxmStandardPosterior(getVariableBlock(object, 
       "rho", which = which, vindex = v), stats = c(0.025, 0.5, 0.975))
   out
}

setMethod("summary",
          "rtxmProfileREffLODsCovariatesModelAR1Zeta",
   function(object, which=NULL){

      if (is.null(which))  which <- object$status - 1
      out <- callNextMethod(object, which=which)
      rtxmAR1ZetaSummaryEngine(object, out, which)
   }
)

setMethod("summary",
          "rtxmProfileREffCovariatesModelAR1Zeta",
   function(object, which=NULL){

      if (is.null(which))  which <- object$status - 1
      out <- callNextMethod(object, which=which)
      rtxmAR1ZetaSummaryEngine(object, out, which)
   }
)

setMethod("summary",
          "rtxmBasicLODsCovariatesModelAR1Zeta",
   function(object, which=NULL){

      if (is.null(which))  which <- object$status - 1
      out <- callNextMethod(object, which=which)
      rtxmAR1ZetaSummaryEngine(object, out, which)
   }
)

setMethod("summary",
          "rtxmBasicCovariatesModelAR1Zeta",
   function(object, which=NULL){

      if (is.null(which))  which <- object$status - 1
      out <- callNextMethod(object, which=which)
      rtxmAR1ZetaSummaryEngine(object, out, which)
   }
)