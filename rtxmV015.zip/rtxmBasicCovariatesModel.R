setMethod("initialize",
          "rtxmBasicCovariatesModel",
     function(.Object, yResponse, xTask, data, timeSpline, zCovariates=NULL, gGroups=NULL,  
        transform=function(u)as.vector(u), localfile=tempfile(),
          rng.seed=NULL, rng.name="base::Mersenne-Twister" # added 1/19/2018
      ){
        .Object <- callNextMethod(.Object, yResponse, xTask, data=data, 
           timeSpline=timeSpline, gGroups=gGroups, transform=transform, localfile=localfile,
           rng.seed=rng.seed, rng.name=rng.name) # added 1/19/2018

        .Object$Z <- model.frame(zCovariates, data, na.action=na.pass)
        .Object$Z <- .Object$Z[.Object$originalDataUsed,,drop=FALSE]

        miss <- rep(FALSE, .Object@nObservations)

        for(j in 1:dim(.Object$Z)[2]) miss <- miss | is.na(.Object$Z[,j])
        if(any(miss)){
           obs <- which( !miss )
           .Object$Z <- .Object$Z[obs,,drop=FALSE]
           .Object$Y <- .Object$Y[obs,,drop=FALSE]
           .Object$X <- .Object$X[obs,,drop=FALSE]
           .Object$G <- .Object$G[obs,,drop=FALSE]
           .Object$spline <- .Object$spline[obs,,drop=FALSE]
           .Object$originalDataUsed <- .Object$originalDataUsed[obs]
         }
         .Object$Z <- model.matrix(zCovariates, data=.Object$Z)[,-1,drop=FALSE]
         .Object@nCovariates <- dim(.Object$Z)[2]

         .Object@nObservations <- length(.Object$originalDataUsed)
         .Object@hyperparameters=c(.Object@hyperparameters, XIPRECISION = 0.0001)

         .Object
     }
)

setMethod("adaptivate",
          "rtxmBasicCovariatesModel",
   function(theObject){
     catch <- try({
       theObject$dataPackage <- rtxmDataPackageBasic(theObject)
       theObject$dataPackage$XIPRECISION <- as.vector(theObject@hyperparameters["XIPRECISION"])
       theObject$dataPackage$covariates <- theObject$Z
       theObject$dataPackage$nCovariates <- theObject@nCovariates

       theObject$initPackage <- list(rtxmInitializeSamplerBasic(theObject,
          model=expression(Y~TaskMatrix+Z-1), extraProcessing=function(object,out){
            out$xi <- coef(object$initialModel)[-(1:object@nTasks)]    
            out     
          }
       ))
       theObject$sampleAllVariables <- names(theObject$initPackage[[1]])
       theObject$sampleStandard <- theObject$sampleAllVariables

       # Added 1/19/2018 to implement setting of random number seed
       if(!is.null(theObject$.RNG.seed)) { 
          theObject$initPackage[[1]]$.RNG.name <- theObject$.RNG.name  
          theObject$initPackage[[1]]$.RNG.seed <- theObject$.RNG.seed 
       }  
       # End 1/19/2018 addition
     })
     if(inherits(catch,"try-error")) return(-2)

     return(-1)
   }
)

setMethod("postprocess",
          "rtxmBasicCovariatesModel",
   function(theObject){
      s <- theObject$status

      rtxmSamplerPostProcessBasic(theObject, s)

      moreCoefs <- grep("^xi", colnames(theObject$sampleHistory[[s]][[1]]))
      names(moreCoefs) <- colnames(theObject$Z)
      theObject$sampleVarIndex[[s]]$coefficients2 <- moreCoefs
      theObject$status+1
   }
)

setMethod("summary",
          "rtxmBasicCovariatesModel",
   function(object, which=NULL){
     out <- callNextMethod(object, which=which)
     
     moreEffects <- getCoefficients(object, which=which, whichSet="covariates")
     #moreEffects <- t(apply(moreEffects,2,rtxmStandardPosterior))
     #out$`fixed effects` <- rbind(out$`fixed effects`, moreEffects)
     out
})

setMethod("getCoefficients",
          "rtxmBasicCovariatesModel",
   function(theObject, which=NULL, vindex=NULL, whichSet="all"){
     if(whichSet=="task"){
       getVariableBlock(theObject,"coefficients",
           which=which,vindex=vindex)
     }
     else if(whichSet=="covariates"){
       getVariableBlock(theObject,"coefficients2",
           which=which,vindex=vindex)
     }
     else if(whichSet=="all"){
       cbind(
         getVariableBlock(theObject,"coefficients",
             which=which,vindex=vindex),
         getVariableBlock(theObject,"coefficients2",
             which=which,vindex=vindex)
       )
     }
   }
)

setMethod("getPredictions",
          "rtxmBasicCovariatesModel",
   function(theObject, whichComponent, which=NULL, vindex=NULL, level=1){
      if(is.null(which)) which <- theObject$status-1

      # Check to see if they've been calculated already
      if(!is.null(theObject$predictions)){ 
          if(theObject$predictions$which == which) 
             return(theObject$predictions$mu)
      }

      # If not, calculate and save them
      v <- theObject$sampleVarIndex[[which]]

      dsgn <- cbind(1,theObject$dataPackage$task,theObject$Z)
      beta <- rbind(
         t(getIntercept(theObject, which=which, vindex=v)),
         t(getCoefficients(theObject, which=which, vindex=v, whichSet="all"))
      )
      sampMu <- dsgn %*% beta 
      if(level>=1){
        for(i in 1:theObject$index1$n){
          zeta <- getVariableBlock(theObject,"zeta",which=which,vindex=vindex,vsubRow=i)
          ii <- theObject$index1$forward[[i]]
          sampMu[ii,] <- sampMu[ii,]+ theObject$spline[ii,] %*% t(zeta) 
        }
      }
      theObject$predictions <- list(which=which, mu=sampMu)
      sampMu 
   }
)

setMethod("getTaskMeans",
          "rtxmBasicCovariatesModel",
   function(theObject, which=NULL, vindex=NULL){
     icpt <- getVariableBlock(theObject,whichBlock="intercept",
       which=which,vindex=vindex)
     coefs <- getVariableBlock(theObject,"coefficients",
         which=which,vindex=vindex)[,1:(theObject@nTasks-1)]
     out <- cbind(icpt, sweep(coefs,1,icpt,"+"))
     colnames(out)[1] <- levels(theObject$X)[1]
     out
   }
)
