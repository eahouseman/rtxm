# UTILITY FUNCTIONS FOR QUANTILE AND AUTOCORRELATION ESTIMATION

library(RColorBrewer)

identityFunction <- function(u)u
antilogCommon <- function(u) 10^u

makeProxySpline <- function(intervalMinutes,minutesPerReading,
  center=0.5, knotsDays, knotsBoundary=c(0,1)){
  nReadings <- intervalMinutes/minutesPerReading
  readingLen <- minutesPerReading/60/24
  proxyTimes <- (1:nReadings)*readingLen
  proxyTimes <- proxyTimes-0.5*(proxyTimes[nReadings]-proxyTimes[1]) + center
  proxyTimes
  bs(proxyTimes, knots=knotsDays, Boundary.knots=c(0,1))
}

drawOneSample <- function(mu,sigmaZ,sigmaE,sp,sigmaA=0,transform=identityFunction){
   d <- dim(sp)[2]
   n <- dim(sp)[1]
   zeta <- rnorm(d,0,sigmaZ)
   alpha <- rnorm(1,0,sigmaA)
   y <- mu + alpha + sp %*% zeta + rnorm(n,0,sigmaE)
   mean( transform(y) ) 
}

drawManySamples <- function(n,mu,sigmaZ,sigmaE,sp,sigmaA=0,transform=identityFunction){
   sapply(1:n, function(i)
    drawOneSample(mu=mu,sigmaZ=sigmaZ,sigmaE=sigmaE,sp=sp,sigmaA=sigmaA,transform=transform))
}

quantilesManySamples <- function(n,mu,sigmaZ,sigmaE,sp,
   quants=seq(1,19)/20,sigmaA=0,transform=identityFunction){
   x <-drawManySamples(n,mu=mu,sigmaZ=sigmaZ,sigmaE=sigmaE,sp=sp,sigmaA=sigmaA,transform=transform)
   quantile(x,quants)
}

localCovariation <- function(sigmaZ,sigmaE,sp,as.corr=FALSE,sigmaA=0,transform=identityFunction){
   v <- (sigmaZ*sigmaZ)*sp%*%t(sp)
   v <- v + sigmaA*sigmaA
   diag(v) <- diag(v) + sigmaE*sigmaE
   if(as.corr) v <- cov2cor(v)
   v
}

getQuantileSeries <- function(nSim, mu, sigmaZ, sigmaE, sp,
   quants=seq(1,19)/20,sigmaA=0,transform=identityFunction){

  nTask <- dim(mu)[2]
  nMCMC <- dim(mu)[1]

  results <- array(NA,dim=c(nMCMC,nTask,length(quants)))
  dimnames(results) <- list(NULL,colnames(mu),100*quants)

  for(i in 1:nMCMC){
    for(j in 1:nTask){
       sigE <- sigmaE[i,j]
       sigZ <- sigmaZ[i]
       sigA <- sigmaA[i]
       results[i,j,] <- quantilesManySamples(nSim, mu[i,j],
          sigZ, sigE, sp, quants=quants, sigmaA=sigA, transform=transform)
    }
    if(i %% 100==0) cat(i,"\n")
  }
  results
}

getAutocorrelation <- function(mu, sigmaZ, sigmaE, sp, minutesPerSample,
   sigmaA=0,transform=identityFunction){

  nTask <- dim(mu)[2]
  nMCMC <- dim(mu)[1]
  nSpAuto <- dim(sp)[1]

  midSpAuto <- ceiling(nSpAuto/2)
  rownames(sp) <- (1:nSpAuto-midSpAuto)*minutesPerSample

  results <- array(NA,dim=c(nMCMC,nTask,nSpAuto,2))
  dimnames(results) <- list(NULL,colnames(mu),rownames(sp),c("cor","sd"))

  for(i in 1:nMCMC){
    for(j in 1:nTask){
       sigE <- sigmaE[i,j]
       sigZ <- sigmaZ[i]
       sigA <- sigmaA[i]
       tmp <- localCovariation(sigZ,sigE, sp, sigmaA=sigA, transform=antilogCommon)
       results[i,j,,1] <- cov2cor(tmp)[,midSpAuto]
       results[i,j,,2] <- sqrt(diag(tmp))
    }
  }
  results
}

quantilePlot <- function(qdata, index=1, 
  trimLeft=0.025, trimRight=0.975, OEL="95", transform=identityFunction){

  quants <- as.numeric(dimnames(qdata)[[3]])/100
  toTrim <- which(quants<=trimRight & quants>=trimLeft)

  quants <- quants[toTrim]
  qdata <- qdata[,,toTrim,drop=FALSE]

  stats <- transform( apply(qdata[,index,],2,quantile,prob=c(0.025,0.5,0.975)) )
  nquants <- length(quants)
  plot(range(quants),range(stats),type="n", xlab="Quantile", ylab="")
  polygon(c(quants,quants[nquants:1]),c(stats[1,],stats[3,nquants:1]),border=NA,col="yellow")
  lines(quants,stats[2,],lwd=3,col="red")
  for(s in 1:3) abline(h=stats[s,OEL],lty=2)
  abline(v=as.numeric(OEL)/100,lty=2)
}

autocorrPlot <- function(adata,pal=brewer.pal(nTask,"Set1"),rightHalf=TRUE){

  nTask <- dim(adata)[2]
  times <- as.numeric(dimnames(adata)[[3]])

  if(nTask==1) {
    stats <- apply(adata[,1,,"cor"],2,quantile,prob=c(0.025,0.5,0.975))
    if(rightHalf) stats <- stats[,times>=0]
  }
  else {
    stats <- apply(adata[,,,"cor"],2:3,quantile,prob=c(0.025,0.5,0.975))
    if(rightHalf) stats <- stats[,,times>=0]
  }

  if(rightHalf) times <- times[times>=0]

  ntimes <- length(times)
  plot(range(times),range(stats),type="n", xlab="minutes", ylab="autocorrelation")

  if(nTask==1) {
    polygon(c(times,times[ntimes:1]),c(stats[1,],stats[3,ntimes:1]),border=NA,col="yellow")
    lines(times,stats[2,],lwd=3,col="black")
  }
  else{
    for(j in 1:nTask){
      lines(c(times,times[ntimes:1]),c(stats[1,j,],stats[3,j,ntimes:1]),col=pal[j],lty=3)
    }
    for(j in 1:nTask){
      lines(times,stats[2,j,],lwd=3,col=pal[j])
    }
    legend("topright",dimnames(adata)[[2]],lty=1,lwd=2,col=pal)
  }
}

varPlot <- function(adata,pal=brewer.pal(max(nTask,3),"Set1")){

  nTask <- dim(adata)[2]
  if(nTask==1) {
    stats <- quantile(apply(adata[,1,,"sd"],1,mean),prob=c(0.025,0.5,0.975))
  }
  else{
    stats <- apply(apply(adata[,,,"sd"],1:2,mean),2,quantile,prob=c(0.025,0.5,0.975))
  }

  plot(c(0.33,nTask+0.66),range(stats),type="n", xaxt="n",
     xlab="", ylab="standard deviation")

  if(nTask>1){
     for(j in 1:nTask){
        #rect(j-1/3,stats[1,j],j+1/3,stats[3,j],col=pal[j])
        lines(c(j,j),stats[c(1,3),j],col=pal[j],lwd=3)
        lines(j+c(-1,1)/6,rep(stats[1,j],2),col=pal[j])
        lines(j+c(-1,1)/6,rep(stats[3,j],2),col=pal[j])
     }
     points(1:nTask,stats[2,],col=pal,pch=19,cex=1.25)
  }
  else{
        lines(c(1,1),stats[c(1,3)],col="black",lwd=3)
        lines(1+c(-1,1)/6,rep(stats[1],2),col="black")
        lines(1+c(-1,1)/6,rep(stats[3],2),col="black")
     points(1,stats[2],col="black",pch=19,cex=1.25)
  }

  axis(1,1:nTask,dimnames(adata)[[2]],tick=FALSE,cex.axis=0.85)
}


getQuantileSeriesOneTimeUnit <- function(mu, sigmaZ, sigmaE, sp,
   quants=seq(1,19)/20,sigmaA=0,transform=identityFunction){

  nTask <- dim(mu)[2]
  nMCMC <- dim(mu)[1]

  results <- array(NA,dim=c(nMCMC,nTask,length(quants)))
  dimnames(results) <- list(NULL,colnames(mu),100*quants)

  for(i in 1:nMCMC){
    for(j in 1:nTask){
       sigE <- sigmaE[i,j]
       sigZ <- sigmaZ[i]
       sigA <- sigmaA[i]
       results[i,j,] <- transform(qnorm(quants, mu[i,j], sqrt(sigA*sigA + sigZ*sigZ*(sp%*%t(sp)) + sigE*sigE)))
    }
    if(i %% 100==0) cat(i,"\n")
  }
  results
}

plotZetaAutocorrelationProfile = function(zeta, do.plot=TRUE, summaryfunction=mean){
   
   zeta.est = apply(zeta,2,summaryfunction)

   n = length(zeta.est)
   nlags = ceiling(n/2)
   r = rep(1,nlags+1)

   for(i in 1:nlags){
      r[i+1] = cor(zeta.est[-(1:i)], zeta.est[(i:1)-n-1])
   }
   names(r) = 0:nlags
   
   if(do.plot){
      plot(0:nlags, r, type="b", pch=19, xlab="lag", ylab="correlation")
      abline(h=0, lty=2)
   }

   invisible(r)
}

estimateEmpiricalZetaAutocorrelationByLME = function(zeta,corModel=corAR1()){
  d = dim(zeta)
  if(length(d)==3) zeta = apply(zeta,c(1,3),mean)
 
  dat = data.frame(
    profile = as.vector(row(zeta)),
    splinef = factor(as.vector(col(zeta))),
    zeta = as.vector(zeta)
  )
  out = list()
  out$lme = lme(zeta~splinef,random=~1|profile,correlation=corModel,data=dat)

  catch = try({
    apv = out$lme$apVar
    out$zstats = attr(apv,"Pars")/sqrt(diag(apv))
  }, silent=TRUE)
  if(inherits(catch,"try-error")) warning("Variance components model is not positive-definite.")
  out
}


